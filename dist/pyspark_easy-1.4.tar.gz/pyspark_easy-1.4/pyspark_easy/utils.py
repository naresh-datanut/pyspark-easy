###########################################################

#Util functions 

def Extract(lst): 
    return [item[0] for item in lst] 